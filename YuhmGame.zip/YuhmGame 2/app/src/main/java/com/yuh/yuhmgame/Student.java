package com.yuh.yuhmgame;

public class Student {
    protected int index;
    protected int x;
    protected int y;
    protected boolean alive;
    protected char face;
    protected int cookieCount;
    protected int freezeCookies;

    public Student(){
        x = 0;
        y = 0;
        index = 1;
        alive = true;
        face = 'r';
        cookieCount = 0;
    }

    public void setPosition(int x, int y){
        this.x = x;
        this.y = y;
    }

    public void Kill(){
        this.alive = false;
    }

    public void collectCookie(){
        cookieCount++;
        freezeCookies++;
    }

    public void turn(char direction){
        switch (direction){
            case 'u':
                this.index = 2;
                break;
            case 'r':
                this.index = 1;
                break;
            case 'd':
                this.index = 4;
                break;
            case 'l':
                this.index = 3;
                break;
        }
    }

    public void move(char move){
        final int MaxColumn = 17;
        final int MaxRow = 11;

        this.face = move;

        switch (move) {
            case 'l':
                if (x - 1 < 3) x = 3;
                else x = x - 1;
                break;
            case 'r':
                if (x + 1 > MaxColumn-1) x = MaxColumn-1;
                else x = x + 1;
                break;
            case 'u':
                if(y - 1 < 0) y = 0;
                else y = y - 1;
                break;
            case 'd':
                if(y + 1 > MaxRow-1) y = MaxRow-1;
                else y = y + 1;
                break;
            default:
                break;
        }
    }
}
