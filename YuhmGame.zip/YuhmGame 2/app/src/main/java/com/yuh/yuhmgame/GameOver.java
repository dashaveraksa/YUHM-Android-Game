package com.yuh.yuhmgame;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class GameOver extends Activity implements View.OnClickListener {

    Button mainMenu,saveScore;
    long scoreval;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.game_over);

        scoreval = getIntent().getLongExtra("SCORE",0);

        TextView score = (TextView) findViewById(R.id.score);
        score.setText("Your Score: " + scoreval);

        saveScore = (Button) findViewById(R.id.save_score);
        saveScore.setOnClickListener(this);


        mainMenu = (Button) findViewById(R.id.main_menu);
        mainMenu.setOnClickListener(this);

    }

    public void onClick(final View v){
        switch(v.getId()){
            case R.id.save_score:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("ENTER YOUR INITIALS");

                // Set up the input
                final EditText input = new EditText(this);
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                input.setFilters(new InputFilter[] {new InputFilter.LengthFilter(3),new InputFilter.AllCaps()});
                builder.setView(input);

                // Set up the buttons
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        name = input.getText().toString();

                        SharedPreferences preferences = getSharedPreferences("PREFS", 0);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putLong("lastScore", scoreval);
                        editor.putString("lastInitials", name);
                        editor.apply();

                        Intent savescore = new Intent(v.getContext(), ScoreBoard.class);
                        startActivity(savescore);
                        finish();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
                break;
            case R.id.main_menu:
                Intent menu = new Intent(v.getContext(), HomeScreen.class);
                startActivity(menu);
                finish();
                break;
        }
    }
}