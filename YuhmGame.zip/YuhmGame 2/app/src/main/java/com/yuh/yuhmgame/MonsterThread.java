package com.yuh.yuhmgame;

public class MonsterThread extends Thread {
	GamePanel gamePanel;
	private Librarian librarian[];
	public char moveChar;
	private int sleeptime = 500;
	private boolean running = false;

	public MonsterThread(GamePanel cv) {
		gamePanel = cv;
	}

	public void setRunning(boolean running) {
        this.running = running;
    }

	public int getDirection(int x, int y) {
		int ret = 0;
		int Student_X = gamePanel.student.x;
		int Student_Y = gamePanel.student.y;

		if (x == Student_X){
			if (y == Student_Y) {ret = 0;}  //Meet
            if (y < Student_Y) {ret = 5;}   //Down
            if (y > Student_Y) {ret = 1;}   //Up
        }
        else if (x < Student_X) {
        	if (y == Student_Y) {ret = 7;}  //right
            if (y < Student_Y) {ret = 6;}   //down-right
            if (y > Student_Y) {ret = 8;}   //up-right
        }
        else if (x > Student_X) {
        	if (y == Student_Y) {ret = 3;} //left
        	if (y < Student_Y) {ret = 4;} //down-left
        	if (y > Student_Y) {ret = 2;} //up-left
        }
        return ret;
		}

		public boolean tryMove(int try_x,int try_y, Librarian librarian){
	    moveChar = 'n';
        if (gamePanel.checkCrumbs( librarian.x+try_x, librarian.y+try_y)){
        	if (try_x == 0 && try_y == -1) {
        		moveChar = 'u';
        	}
        	else if (try_x == 0 && try_y == 1) {
                moveChar = 'd';
            }
        	else if (try_x == 1 && try_y == 0) {
        		moveChar = 'r';
        	}
        	else if (try_x == -1 && try_y == 0) {
        		moveChar = 'l';
        	}
            librarian.move(moveChar);
            return true;
        }

        else{return false;}
    }

        public void findOrder(int direction, Librarian librarian){
        switch (direction){
            case 1:
            case 2:{
                if (!tryMove(0,-1,librarian)){
                    if (!tryMove(-1,0,librarian)){
                        if (!tryMove(1,0,librarian)){
                            tryMove(0,1,librarian);
                        }
                    }
                }
                break;
            }
            case 3:    //left-up-down-right
            case 4:{
                if (!tryMove(-1,0,librarian)){
                    if (!tryMove(0,1,librarian)){
                        if (!tryMove(0,-1,librarian)){
                            tryMove(1,0,librarian);
                        }
                    }
                }
                break;
            }
            case 5:
            case 6:{    //up-right-left-down
                if (!tryMove(0,1,librarian)){
                    if (!tryMove(1,0,librarian)){
                        if (!tryMove(-1,0,librarian)){
                            tryMove(0,-1,librarian);
                        }
                    }
                }
                break;
            }
            case 7:   //right-down-up-left
            case 8:{
                if (!tryMove(1,0,librarian)){
                    if (!tryMove(0,-1,librarian)){
                        if (!tryMove(0,1,librarian)){
                            tryMove(-1,0,librarian);
                        }
                    }
                }
                break;
            }
            default:{break;}
        }

    }

    public void run() {
        while (running) {
            librarian = new Librarian[3];
            librarian[0] = gamePanel.librarian[0];
            librarian[1] = gamePanel.librarian[1];
            librarian[2] = gamePanel.librarian[2];

            while (!(gamePanel.getGameOver())) {
                if(gamePanel.pause){
                    try {
                        sleep(2000);
                        gamePanel.pause = false;
                    } catch (InterruptedException e) {
                        System.out.println("Exception occured.");
                    }
                }
                if(gamePanel.freeze){
                    try {
                        sleep(5000);
                        gamePanel.freeze = false;
                    } catch (InterruptedException e) {
                        System.out.println("Exception occured.");
                    }
                }

                for (int i = 0; i < 3; i++) {
                    if (!librarian[i].frozen) {
                        int direction = getDirection(librarian[i].x, librarian[i].y);
                        //Move
                        findOrder(direction, librarian[i]);
                    }
                }
                try {
                    sleep(sleeptime);
                    sleeptime = 500;
                } catch (InterruptedException e) {
                    System.out.println("Exception occured.");
                }

            }
        }
    }
}

