package com.yuh.yuhmgame;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class HomeScreen extends Activity implements View.OnClickListener {

    Button playButton,scoreButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.home_screen);

        playButton = (Button) findViewById(R.id.playButton);
        playButton.setOnClickListener(this);

        scoreButton = (Button) findViewById(R.id.scoreButton);
        scoreButton.setOnClickListener(this);
    }

    public void onClick(View v){
        switch(v.getId()){
            case R.id.playButton:
                Intent play = new Intent(v.getContext(), GameActivity.class);
                startActivity(play);
                finish();
                break;
            case R.id.scoreButton:
                Intent score = new Intent(v.getContext(), ScoreBoard.class);
                startActivity(score);
                finish();
                break;
        }
    }
}
