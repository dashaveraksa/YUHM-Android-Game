package com.yuh.yuhmgame;

public class layer {
    private int index;
    public int x;
    public int y;
    protected boolean isItem;
    protected boolean crumbs = false;

    public layer(int x, int y){
        this.x = x;
        this.y = y;
        this.isItem = false;
        this.index = 10; //cookie crumbs
    }

    public void setCookie() {
        this.isItem = true;
        this.index = 11; //cookie
    }

    public void setCrumbs() {
        this.isItem = true;
        crumbs = true;
        this.index = 10; //cookie crumbs
    }

    public void reSet(){
        this.crumbs = false;
        this.isItem = false;
    }

    public int getIndex(){
        return index;
    }
}
