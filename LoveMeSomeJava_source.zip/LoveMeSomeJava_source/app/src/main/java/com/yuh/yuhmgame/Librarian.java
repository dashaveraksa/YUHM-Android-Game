package com.yuh.yuhmgame;

public class Librarian {
	private int index = 12;
	protected int x;
	protected int y;
	protected boolean frozen;

	public Librarian(){
		this.x = 0;
		this.y = 0;
		this.frozen = false;
	}

	public void setPosition(int x, int y){
		this.x = x;
		this.y = y;
	}

	 public void move(char move) {
        final int MaxColumn=17;
        final int MaxRow=11;

        switch(move) {
        	case 'r':
        		if(this.x+1 > MaxColumn-1) {
        			this.x = MaxColumn-1;
        		}
        		else {
        			this.x += 1;
        		}
        		break;
        	case 'l':
        		if(this.x-1 < 3) {
        			this.x = 3;
        		}
            	else {
        			this.x -= 1;
        		}
        		break;
        	case 'd':
        		if(this.y + 1 > MaxRow-1) {
        			this.y = MaxRow-1;
        		}
        		else {
        			this.y += 1;
        		}
        		break;
        	case 'u':
        		if(this.y - 1 < 0) {
        			this.y = 0;
        		}
        		else {
        			this.y -= 1;
        		}
        		break;
			default:
				break;
        }
    }

    public int getIndex() {
        return index;
    }
}


