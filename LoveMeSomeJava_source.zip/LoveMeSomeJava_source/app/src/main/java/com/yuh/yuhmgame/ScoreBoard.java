package com.yuh.yuhmgame;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

public class ScoreBoard extends Activity {
    TextView yourScore,firstScore,secondScore,thirdScore;
    long lastScore, first, second, third;
    String lastInitials,firstInitials,secondInitials,thirdInitials;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.score_board);

        yourScore = findViewById(R.id.yourscore);
        firstScore = findViewById(R.id.first);
        secondScore = findViewById(R.id.second);
        thirdScore = findViewById(R.id.third);

        SharedPreferences preferences = getSharedPreferences("PREFS", 0);
        lastScore = preferences.getLong("lastScore", 0);
        lastInitials = preferences.getString("lastInitials", "");
        first = preferences.getLong("first", 0);
        firstInitials = preferences.getString("firstInitials", "");
        second = preferences.getLong("second", 0);
        secondInitials = preferences.getString("secondInitials", "");
        third = preferences.getLong("third", 0);
        thirdInitials = preferences.getString("thirdInitials", "");

        if(lastScore >= first) {
            Long temp1 = first;
            Long temp2 = second;
            String tempname1 = firstInitials;
            String tempname2 = secondInitials;
            first = lastScore;
            firstInitials = lastInitials;
            second = temp1;
            secondInitials = tempname1;
            third = temp2;
            thirdInitials = tempname2;
            SharedPreferences.Editor editor = preferences.edit();
            editor.putLong("first", first);
            editor.putString("firstInitials",firstInitials);
            editor.putLong("second", second);
            editor.putString("secondInitials",secondInitials);
            editor.putLong("third", third);
            editor.putString("thirdInitials",thirdInitials);
            editor.apply();
        }else if(lastScore >= second) {
            Long temp = second;
            String tempname = secondInitials;
            second = lastScore;
            secondInitials = lastInitials;
            third = temp;
            thirdInitials = tempname;
            SharedPreferences.Editor editor = preferences.edit();
            editor.putLong("second", second);
            editor.putString("secondInitials",secondInitials);
            editor.putLong("third", third);
            editor.putString("thirdInitials",thirdInitials);
            editor.apply();
        }else if(lastScore >= third) {
            third = lastScore;
            thirdInitials = lastInitials;
            SharedPreferences.Editor editor = preferences.edit();
            editor.putLong("third", third);
            editor.putString("thirdInitials",thirdInitials);
            editor.apply();
        }

        CharSequence scoreText = "Your Score:" + lastScore;
        CharSequence firstText = firstInitials + ": " +first;
        CharSequence secondText = secondInitials + ": " + second;
        CharSequence thirdText = thirdInitials + ": " +third;
        yourScore.setText(scoreText);
        firstScore.setText(firstText);
        secondScore.setText(secondText);
        thirdScore.setText(thirdText);

    }


    @Override
    public void onBackPressed() {
        SharedPreferences preferences = getSharedPreferences("PREFS", 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.remove("lastScore");
        editor.remove("lastInitials");
        editor.apply();
        Intent intent = new Intent(getApplicationContext(), HomeScreen.class);
        startActivity(intent);
        finish();
    }

}
