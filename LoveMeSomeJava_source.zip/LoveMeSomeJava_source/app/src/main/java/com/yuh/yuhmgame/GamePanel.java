package com.yuh.yuhmgame;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.Random;


public class GamePanel extends SurfaceView implements SurfaceHolder.Callback {
    private MainThread thread;
    private MonsterThread monsterthread;
    private Bitmap icons[];
    protected layer items[][];
    protected final int numRows = 11;
    protected final int numColumns = 17;
    protected Student student;
    protected char direction = 'n';
    protected Librarian librarian[];
    public boolean GameOver = false;
    protected boolean isTouch = false;
    private int resetCount = 0;
    private long startTime;
    private long finalTime;
    private Random rand;
    private boolean intersect;
    protected boolean pause;
    protected boolean freeze;
    protected boolean freezeAble = false;
    protected long lastFreezeTime = 0;
    protected int freezeCount = 0;


    public GamePanel(Context context) {
        super(context);

        getHolder().addCallback(this);

        thread = new MainThread(getHolder(), this);

        setFocusable(true);

        startTime = System.currentTimeMillis();

        icons = new Bitmap[13];
        student = new Student();
        librarian = new Librarian[3];
        librarian[0] = new Librarian();
        librarian[1] = new Librarian();
        librarian[2] = new Librarian();
        items = new layer[numColumns][numRows];
        rand = new Random();

        for (int i = 0; i < numColumns; i++){
            for (int j = 0; j < numRows; j++) {
                items[i][j]=new layer(i,j);
            }
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        thread = new MainThread(getHolder(), this);
        monsterthread = new MonsterThread(this);

        //Solid Background
        icons[0] = BitmapFactory.decodeResource(getResources(), R.drawable.background);

        //Student
        icons[1] = BitmapFactory.decodeResource(getResources(), R.drawable.studentright);
        icons[2] = BitmapFactory.decodeResource(getResources(), R.drawable.studentup);
        icons[3] = BitmapFactory.decodeResource(getResources(), R.drawable.studentleft);
        icons[4] = BitmapFactory.decodeResource(getResources(), R.drawable.studentdown);

        //Buttons
        icons[5] = BitmapFactory.decodeResource(getResources(), R.drawable.arrowright);
        icons[6] = BitmapFactory.decodeResource(getResources(), R.drawable.arrowup);
        icons[7] = BitmapFactory.decodeResource(getResources(), R.drawable.arrowleft);
        icons[8] = BitmapFactory.decodeResource(getResources(), R.drawable.arrowdown);
        icons[9] = BitmapFactory.decodeResource(getResources(), R.drawable.freeze);

        //Items
        icons[10] = BitmapFactory.decodeResource(getResources(), R.drawable.cookiecrumbs);
        icons[11] = BitmapFactory.decodeResource(getResources(), R.drawable.cookie);

        //Librarian
        icons[12] = BitmapFactory.decodeResource(getResources(), R.drawable.librarian);


        thread.setRunning(true);
        thread.start();
        monsterthread.setRunning(true);
        monsterthread.start();

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        while(retry){
            try{
                thread.setRunning(false);
                monsterthread.setRunning(false);
                thread.join();
                monsterthread.join();
            } catch(Exception e){e.printStackTrace();}
            retry = false;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        int touchX;
        int touchY;
        int width = getWidth();
        int height = getHeight();
        int rowHeight = height/numRows;
        int columnWidth = width/numColumns;

        if(event.getAction() == MotionEvent.ACTION_DOWN){
            isTouch = true;
            touchX = ((int) event.getX())/columnWidth;
            touchY = ((int) event.getY())/rowHeight;

            if(touchX==2 && touchY==9) {
                direction = 'r';
                student.move(direction);
                student.turn(direction);
            }
            if(touchX==1 && touchY==8) {
                direction = 'u';
                student.move(direction);
                student.turn(direction);
            }
            if(touchX==0 && touchY==9) {
                direction = 'l';
                student.move(direction);
                student.turn(direction);
            }
            if(touchX==1 && touchY==10) {
                direction = 'd';
                student.move(direction);
                student.turn(direction);
            }
            if((touchX >=  0 && touchX <=2) && (touchY <= 6 && touchY >= 3)){
                if(freezeAble){
                    lastFreezeTime = System.currentTimeMillis();
                    student.freezeCookies -= 3;
                    freeze = true;
                }
            }
        }
        else if(event.getAction() == MotionEvent.ACTION_UP){
            isTouch = false;
        }

        return super.onTouchEvent(event);
    }

    public boolean checkCrumbs(int x, int y){
        if((x<numColumns)&&(x>=3)&&(y<numRows)&&(y>=0)){
            for (int i = 0; i < 3; i++){
                if(librarian[i].x == x && librarian[i].y == y) {
                    return false;
                }
            }
            return items[x][y].crumbs;
        }
        else{
            return false;
        }
    }

    public boolean getGameOver(){
        return GameOver;
    }

    public long getScore(){
        if (student.alive)
        {
            finalTime = System.currentTimeMillis();
        }
        return ((finalTime-startTime)/1000)*10 + 100*student.cookieCount;
    }

    public void update(){

    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        canvas.drawColor(Color.rgb(230,175,46));
        Rect rect = new Rect();
        int width = getWidth();
        int height = getHeight();

        int rowHeight = height/numRows;
        int colWidth = width/numColumns;

        int numLibrarians = 3;

        if (((student.cookieCount % 5) == 0) && (student.cookieCount/5 == resetCount)){

            monsterthread.setRunning(false);
            pause = true;

            // random student position
            int studentX = rand.nextInt(numColumns-3)+3;
            int studentY = rand.nextInt(numRows);
            student.setPosition(studentX,studentY);


            // random librarian positions
            for (int i = 0 ; i < numLibrarians; i++){
                do {
                    intersect = false;
                    int x = rand.nextInt(numColumns - 3) + 3;
                    int y = rand.nextInt(numRows);
                    librarian[i].setPosition(x,y);

                    if((librarian[i].x == student.x) && (librarian[i].y == student.y)) {intersect = true;}

                    for (int j = i-1; j >= 0; j--) {
                        if ((librarian[i].x == librarian[j].x) && (librarian[i].y == librarian[j].y)) {intersect = true;}
                    }
                }while(intersect);
            }


            // reset cookies and crumbs
            for (int i = 0; i < numColumns; i++){
                for (int j = 0; j < numRows; j++) {
                    items[i][j].reSet();
                }
            }

            //make default crumb trail
            for (int i = 0; i < numLibrarians; i++) {
                if (librarian[i].y - student.y > 0) {
                    for (int y = librarian[i].y; y >= student.y; y--) {
                        items[librarian[i].x][y].setCrumbs();
                    }
                }
                else{
                    for (int y = librarian[i].y; y <= student.y; y++) {
                        items[librarian[i].x][y].setCrumbs();
                    }
                }
                if (librarian[i].x - student.x > 0) {
                    for (int x = librarian[i].x; x >= student.x; x--) {
                        items[x][student.y].setCrumbs();
                    }
                }
                else{
                    for (int x = librarian[i].x; x <= student.x; x++) {
                        items[x][student.y].setCrumbs();
                    }
                }
            }


            //random cookies
            for (int i = 0; i < 5; i++) {
                int x;
                int y;
                do {
                    intersect = false;
                    x = rand.nextInt(numColumns - 3) + 3;
                    y = rand.nextInt(numRows);


                    if (x == student.x && y == student.y) {
                        intersect = true;
                    }

                    for (int j = i-1; j >= 0; j--) {
                        if (items[x][y].isItem && (items[x][y].getIndex() == 11)) {intersect = true;}
                    }
                } while(intersect);
                items[x][y].setCookie();
            }

            resetCount++;
            monsterthread.setRunning(true);
        }

        if((student.freezeCookies >= 3)&&((System.currentTimeMillis()-lastFreezeTime)/1000 > 10)){
            freezeAble = true;
        }
        else{
            freezeAble = false;
        }

        // draw background
        rect.set(3 * colWidth, 0 * rowHeight,17 * colWidth, 11 * rowHeight);
        canvas.drawBitmap(icons[0],null,rect,null);

        for (int i = 3; i < 17; i++){
            for (int j = 0; j < 11; j++){
                if(items[i][j].isItem == true) {
                    rect.set(i * colWidth, j * rowHeight, (i + 1) * colWidth, (j + 1) * rowHeight);
                    canvas.drawBitmap(icons[items[i][j].getIndex()], null, rect, null);
                }
                else{
                    rect.set(i * colWidth,j * rowHeight,(i+1) * colWidth, (j+1) * rowHeight);
                    canvas.drawBitmap(icons[0],null,rect,null);
                }
            }
        }

        // draw buttons
        rect.set(2 * colWidth, 9 * rowHeight, (2 + 1) * colWidth, (9 + 1) * rowHeight);
        canvas.drawBitmap(icons[5], null, rect, null);

        rect.set(1 * colWidth, 8 * rowHeight, (1 + 1) * colWidth, (8 + 1) * rowHeight);
        canvas.drawBitmap(icons[6], null, rect, null);

        rect.set(0 * colWidth, 9 * rowHeight, (0 + 1) * colWidth, (9 + 1) * rowHeight);
        canvas.drawBitmap(icons[7], null, rect, null);

        rect.set(1 * colWidth, 10 * rowHeight, (1 + 1) * colWidth, (10 + 1) * rowHeight);
        canvas.drawBitmap(icons[8], null, rect, null);

        if(freezeAble){
            rect.set(0 * colWidth, 4 * rowHeight, (0 + 3) * colWidth, (4 + 3) * rowHeight);
            canvas.drawBitmap(icons[9], null, rect, null);
        }

        // draw student
        if(student.alive) {
            rect.set(student.x * colWidth, student.y * rowHeight, (student.x + 1) * colWidth, (student.y + 1) * rowHeight);
            canvas.drawBitmap(icons[student.index], null, rect, null);
            if((items[student.x][student.y].isItem) &&(items[student.x][student.y].getIndex() == 11)){
                student.collectCookie();
                items[student.x][student.y].reSet();
            }
            if (!(items[student.x][student.y].isItem)) {
                items[student.x][student.y].setCrumbs();
            }
        }
        else{
            thread.setRunning(false);
            monsterthread.setRunning(false);
            Intent gameover = new Intent(getContext().getApplicationContext(),GameOver.class);
            gameover.putExtra("SCORE", getScore());
            gameover.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            getContext().startActivity(gameover);
            ((Activity) getContext()).finish();
            return;
        }

        // draw librarian
        for(int i = 0; i < numLibrarians; i++) {
            rect.set(librarian[i].x * colWidth, librarian[i].y * rowHeight, (librarian[i].x + 1) * colWidth, (librarian[i].y + 1) * rowHeight);
            canvas.drawBitmap(icons[librarian[i].getIndex()], null, rect, null);

            if ((librarian[i].x == student.x) && (librarian[i].y == student.y)){
                student.Kill();
                GameOver = true;
            }
        }

        //Draw score
        Paint p = new Paint(Color.BLACK);
        p.setTextSize(64);  // Set text size
        p.setColor(Color.BLACK);
        p.setTextAlign(Paint.Align.LEFT);
        p.setFakeBoldText(true);
        String scoreText = "Score:";
        canvas.drawText(scoreText, 16,64,p);
        String scoreNum = "  " + getScore();
        canvas.drawText(scoreNum, 16,128,p);

        //System.out.println(getScore());
    }
}
